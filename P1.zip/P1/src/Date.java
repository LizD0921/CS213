import java.util.Calendar;

public class Date implements Comparable<Date> {
    public static final int QUADRENNIAL = 4;
    public static final int CENTENNIAL = 100;
    public static final int QUARTERCENTENNIAL = 400;

    private int year;
    private int month;
    private int day;

    public Date(String date){ // format mm/dd/yyyy
        month = Integer.parseInt(date.substring(0, 2));
        day = Integer.parseInt(date.substring(3, 5));
        year = Integer.parseInt(date.substring(6));

    }

    public Boolean isValid() {  // check if the date is a valid calendar date
        if(year % QUADRENNIAL == 0) {
            if(year % CENTENNIAL == 0) {
                if(year % QUARTERCENTENNIAL == 0) {
                    return true;
                }
                return false;
            }
            return true;
        }
        return false;
    }

    @Override
    public int compareTo(Date date) {
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Date) {
            Date date = (Date) obj;
            return this.month == date.getMonth()
                    && this.day == date.getDay()
                    && this.year == date.getYear();
        }
        return false;
    }

    private int getMonth() {
        return month;
    }

    private int getDay() {
        return day;
    }


    private int getYear() {
        return year;
    }

    @Override
    public String toString() {
        return month + "/" + day + "/" + year;
    }

    public static void main(String[] args) {
        // test isValid()
        Date d1 = new Date("01/01/2000"); // leap year: divisible by 100 and 400
        Date d2 = new Date("01/01/1900"); // not a leap year: divisible by 100 but not 400
        Date d3 = new Date("01/01/2023"); // not a leap year
        Date d4 = new Date("01/01/2024"); // leap year: divisible by 4

        System.out.println(d1 + " is a leap year: " + d1.isValid());
        System.out.println(d2 + " is a leap year: " + d2.isValid());
        System.out.println(d3 + " is a leap year: " + d3.isValid());
        System.out.println(d4 + " is a leap year: " + d4.isValid());

        // test equals()
        Date d5 = new Date("01/01/2000");
        System.out.println("d1 equal to d5: " + d1.equals(d5)); // should print true
        System.out.println("d2 equal to d5: " + d2.equals(d5)); // should print false
    }
}