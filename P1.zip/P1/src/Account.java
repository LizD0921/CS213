public class Account implements Comparable<Account> {
    private AccountNumber   number;
    private Profile         holder;
    private double          balance;

    public Account(){
    }

    public void withdraw(double amount) {   // to update the balance
        balance -= amount;
    }
    public void deposit(double amount) {    // to update the balance
        balance += amount;
    }

    @Override
    public int compareTo(Account account) {
        return 0;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof Account) {
            Account account = (Account) obj;
            return this.number == account.number;
        }
        return false;
    }

    @Override
    public String toString(){ // format: Account#[200017410] Holder[John Doe 2/19/2000] Balance[$600.00] Branch [BRIDGEWATER]
        return "Account#[" + number + "] Holder[" + holder + "] Balance[" + balance + "] Branch [" + "]" ;
    }

    /*
    private double getBalance() {
        return balance;
    }

    private Profile getHolder() {
        return holder;
    }

    private AccountNumber getNumber() {
        return number;
    }
     */

}