public class Archive {
    //private AccountNode first; // the head node of the linked list

    //public void add(Account account() {} // add to front of linked list
    public void print() {} // print the linked list
}
