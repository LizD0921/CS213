import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter one line of code: ");
        String line = scn.nextLine();
        System.out.println("Line entered: " + line);
        scn.close();
    }
}