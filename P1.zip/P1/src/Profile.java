public class Profile implements Comparable<Profile> {
    private String fname;
    private String lname;
    private Date dob;

    public Profile(String fname, String lname, Date dob) {
        this.fname = fname;
        this.lname = lname;
        this.dob = dob;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Profile) {
            Profile profile = (Profile) obj;
            return this.fname.equals(profile.getFname())
                    && this.lname.equals(profile.getLname())
                    && this.dob.equals(profile.getDob());
        }
        return false;
    }

    @Override
    public int compareTo(Profile profile) {
        return -1;
    }

    @Override
    public String toString() {
        return "First name: " + fname + "\tLast name: " + "\tDOB: " + dob;
    }

    private String getFname() {
        return fname;
    }

    private String getLname() {
        return lname;
    }

    private Date getDob() {
        return dob;
    }

    public static void main(String[] args) {
        Date dob1 = new Date("07/18/2003");
        Profile p1 = new Profile("Elizabeth", "Detal", dob1);
        Date dob2 = new Date("01/01/2000");
        Profile p2 = new Profile("John", "Smith", dob2);

        System.out.println("p1 equals p2: " + p1.equals(p2));
        //System.out.println("p1 compareTo p2: " + p1.compareTo(p2));
        System.out.println(p1);
        System.out.println(p2);

    }
}