public class RunProject1 {
    public static void main(String[] args) {
        new TransactionManager().run();
    }
}
