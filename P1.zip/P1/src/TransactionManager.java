public class TransactionManager {

    public void run() {
        //commands
        String input = "A";
        switch (input) {
            case "O":
                System.out.println("tasks for O here:");
                break;
            case "C":
                System.out.println("tasks for C here:");
                break;
            case "D":
                System.out.println("tasks for D here:");
                break;
            case "W":
                System.out.println("tasks for W here:");
                break;
            case "P":
                System.out.println("tasks for P here:");
                break;
            case "PA":
                System.out.println("tasks for PA here:");
                break;
            case "PB":
                System.out.println("tasks for PB here:");
                break;
            case "PH":
                System.out.println("tasks for PH here:");
                break;
            case "PT":
                System.out.println("tasks for PT here:");
                break;
            case "Q":
                System.out.println("Transaction Manager is terminated.");
                break;
            default: // invalid inputs
                System.out.println("invalid input");
                // loop back or quit? maybe ask again

        }

    }
}