public enum AccountType {
    CHECKING("01"),
    SAVINGS("02"),
    MONEY_MARKET("03");
    private String code;

    AccountType(String code){
        this.code = code;
    }

}
