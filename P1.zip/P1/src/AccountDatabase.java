public class AccountDatabase {
    private Account[] accounts;
    private int size;
    private Archive archive; // a linked list of closed account
    private final int CAPACITY = 4;
    private final int NOT_FOUND = -1;

    public AccountDatabase() {
        size = CAPACITY;
        accounts = new Account[size];
        archive = new Archive(); // mod

    }

    // sequential search, modify
    private int find(Account account) {
        for(int i = 0; i < size; i++) {
            if (accounts[i].equals(account)) {
                return i;
            }
        }
        return NOT_FOUND;
    } // return the index or -1 not found.

/*
int bin_search(char *word, int start, int end){
    int mid = (int) (start + end) / 2;
    int i;
    //compare word with dict words
    //convert word and dict words to lower in order to properly compare
    char temp_dict[WORD_SIZE];
    //strcpy(temp_dict, dictionary[mid]);

    for(i = 1; temp_dict[i] != '\0'; i++){
        temp_dict[i] = tolower(temp_dict[i]);
    }

    int comp = strcmp(word, temp_dict);

    if(start > end){   //not found
        return -1;
    }
    else if(comp == 0){  //found
        return mid;
    }
    else if(comp < 0){  //in first half
        return bin_search(word, start , mid - 1);
    }
    else{   // in latter half
        return bin_search(word, mid + 1, end);
    }
}
 */

    private void grow() { // increase the array capacity by 4
        Account[] temp = new Account[size + 4];
        for(int i = 0; i < size; i++) {
            temp[i] = accounts[i];
        }
        accounts = temp;
    }

    public boolean contains(Account account) { //sequential search
        for(int i = 0; i < size; i++) {
            if (accounts[i].equals(account)) {
                return true;
            }
        }
        return false;
    } // check before add/remove

    public void add(Account account) {
        if (contains(account)) {
            if()
        }
    } // add to end of array

    public void remove(Account account) {
    } // replace it with the last item

    public Boolean withdraw(AccountNumber number, double amount) {
        return false;
    }

    public Boolean deposit(AccountNumber number, double amount) {
    }

    public void printArchive() {
    } //print closed accounts

    public void printByBranch() {
    }

    public void printByHolder() {
    }

    public void printByType() {
    }
}